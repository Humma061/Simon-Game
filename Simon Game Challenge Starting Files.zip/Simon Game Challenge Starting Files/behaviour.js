var level = 0;
var gamePattern = []; // Store the game sequence
var userPattern = []; // Store the user's clicks
var buttonColors = ["green", "red", "yellow", "blue"]; // Possible buttons

// Function to play sound for a button
function playSound(name) {
    var audio = new Audio("sounds/" + name + ".mp3"); // Assume you have corresponding sound files
    audio.play();
}

// Function to animate button press (like fading out and in)
function animatePress(color) {
    $("#" + color).fadeOut(100).fadeIn(100); // Button hides and reappears
}

// Function to start the next level
function nextSequence() {
    userPattern = []; // Reset the user's pattern for the next level
    level++;
    $("h1").text("Level " + level); // Update the level in the heading
    
    // Choose a random button and perform actions
    var randomChosenColor = buttonColors[Math.floor(Math.random() * 4)];
    gamePattern.push(randomChosenColor);
    
    // Animate the random button
    animatePress(randomChosenColor);
    playSound(randomChosenColor); // Play the sound associated with the button
}

// Function to check the user's input
function checkAnswer(currentLevel) {
    if (userPattern[currentLevel] === gamePattern[currentLevel]) {
        // Check if user has completed the sequence for the current level
        if (userPattern.length === gamePattern.length) {
            setTimeout(function() {
                nextSequence(); // Move to the next level after a short delay
            }, 1000);
        }
    } else {
        gameOver();
    }
}

// Function to handle game over
function gameOver() {
    playSound("wrong"); // Play wrong sound
    $("h1").text("Game Over, Press Any Key to Restart");
    $("body").addClass("game-over");
    setTimeout(function() {
        $("body").removeClass("game-over");
    }, 200);

    // Restart the game on next key press
    startOver();
}

// Function to restart the game
function startOver() {
    $(document).keypress(function() {
        gamePattern = [];
        level = 0;
        nextSequence(); // Restart the game
    });
}

// Listen for keypress to start the game
$(document).keypress(function() {
    $("h1").text("Level 1");
    nextSequence(); // Start the game
});

// Listen for button clicks
$(".btn").click(function() {
    var userChosenColor = $(this).attr("id"); // Get the button's id
    userPattern.push(userChosenColor); // Add the chosen color to the user's pattern

    playSound(userChosenColor); // Play the corresponding sound
    animatePress(userChosenColor); // Animate the button

    checkAnswer(userPattern.length - 1); // Check the user's answer
});
